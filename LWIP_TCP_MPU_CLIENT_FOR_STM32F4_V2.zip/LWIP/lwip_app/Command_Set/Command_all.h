/*
	This file is to store all TCP remote commands.
	Author: 	Eason. Yang
	Contact:	yyichen@kth.se
	Date:		2019-08-09
*/
#include "sys.h"

#define COMMAND_NUM             6

u8 Comm_Set[COMMAND_NUM][30]=
{
{"Light bulb open!"},
{"Light bulb close!"},
{"BEEP!"},
{"Get MPU data!"},
{"Get MPU Processed data!"},
{"Stop receiving MPU data!"}
};

u8 ASSERT_1[]="Temperature:";
u8 ASSERT_2[]="Gyro data:(";
u8 ASSERT_3[]="Accel data:(";
u8 ASSERT_4[]="pitch: ";
u8 ASSERT_5[]="roll : ";
u8 ASSERT_6[]="yaw  : ";

u8 Comm_1_resp[]="Command Accepted!\r\n";
u8 Comm_2_resp[]="Command Accepted!\r\n";
u8 Comm_3_resp[]="Command BEEP Accepted!\r\n";
u8 Comm_4_resp[]="Start receiving MPU Data!\r\n";
u8 Comm_5_resp[]="Start receiving MPU Processed Data!\r\n";
u8 Comm_6_resp[]="Stop receiving MPU Data!\r\n";
u8 Comm_Break_resp[]="MPU Data Terminate from the Client!\r\n";
u8 Comm_6050_Init_Error[]="MPU Init Error\r\n";




