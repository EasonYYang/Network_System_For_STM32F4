/*
	TCP remote command identifying and processing program, header files.
	Author: 	Eason. Yang
	Contact:	yyichen@kth.se
	Date:		2019-08-09
*/
#include "sys.h"
#include "lwip/debug.h"
#include "lwip/stats.h"
#include "lwip/tcp.h"
#include "lwip/memp.h"
#include "lwip/mem.h"
#include "lwip_comm.h"

typedef void (*comm_func)(void);

struct comm_chain{
	u8 *caption;
	struct comm_chain *next;
	comm_func comm_function;
};

struct MPU_Raw{
	short raw_temperature;
	short gyro[3];
	short accel[3];
	float pitch;
	float roll;
	float yaw;
};
/*
struct MPU_Output{
	short Temperature;
	short gyro[3];
	short accel[3];
};
*/
void func_com_1(void);
void func_com_2(void);
void func_com_3(void);
void func_com_4(void);
void func_com_5(void);
void func_com_6(void);
void Construct_command_chain(struct comm_chain *Command);

void convert(short x,u8 temp[8],u8 int_num);
u8 Get_MPU_Data(struct MPU_Raw *MPU_Packet);
void Send_MPU_Data(struct MPU_Raw *MPU_Packet);
void Data_Process(struct MPU_Raw *Raw_data);
//void mpu6050_send_data(short aacx,short aacy,short aacz,short gyrox,short gyroy,short gyroz);
void Show_RT_MPU(struct MPU_Raw *MPU_Packet,u8 t);//t: refresh rate


