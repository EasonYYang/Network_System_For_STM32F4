#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#define uchar unsigned char
#define uint unsigned int

int pows(int x)
{
	int y = 1;
	for (; x != 0; x--)
		y = y * 10;
	return y;
}

void display_result(float result)
{
    if(result<0)
    {
        printf("-");
        display_result(-result);
    }
    if(result>0)
    {
        float i;
        int x;
        uint y;
        i=1;
        for(x=0;i>=1;x++)
            i=result/pows(x+1);
        for(;x!=0;x--)
        {
            y=((uint)(result/pows(x-1)))%10;
            printf("%d",y);
        }
        printf(".");
        i=result-(uint)result;
        for(x=0;x<6;x++)
        {
            y=((uint)(i*pows(x+1)))%10;
            printf("%d",y);
        }
    }
}
/*
--------------------- 
���ߣ�worlderdone 
��Դ��CSDN 
ԭ�ģ�https://blog.csdn.net/worlderdone/article/details/80147255 
��Ȩ����������Ϊ����ԭ�����£�ת���븽�ϲ������ӣ�
*/
