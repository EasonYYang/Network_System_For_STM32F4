/*
	IIC_6050 Header file, containing IIC communication functions, the corresponding pins may vary according to hardware connection.
	Author: 	Eason. Yang
	Contact:	yyichen@kth.se
	Date:		2019-08-09
*/

#ifndef __IIC_6050_H
#define __IIC_6050_H

#include "sys.h"
#define MPU_SDA_IN()  {GPIOB->MODER&=0XFFF3FFFF;/*GPIOB->CRH|=8<<12;*/}
#define MPU_SDA_OUT() {GPIOB->MODER&=0XFFF3FFFF;GPIOB->MODER|=4<<16;}

#define MPU_IIC_SDA_OUT PBout(9)
#define MPU_IIC_SCL_OUT PBout(8)

#define MPU_IIC_SDA_IN PBin(9)
#define MPU_IIC_SCL_IN PBin(8)



#define IIC_MODE

#ifdef IIC_MODE
	#define START IIC_Start
	#define STOP IIC_End
	#define SEND_1 Send_onebyte
	#define READ_1 Read_onebyte
	#define WAIT_ACK IIC_WaitACK
#else 
	#define START MPU_IIC_Start
	#define STOP MPU_IIC_Stop
	#define SEND_1 MPU_IIC_Send_Byte
	#define READ_1 MPU_IIC_Read_Byte 
	#define WAIT_ACK MPU_IIC_Wait_Ack	
#endif



void IIC_6050_init(void);
void IIC_Start(void);
void IIC_End(void);
u8 IIC_WaitACK(void);
void IIC_Send_Ack(void);
void IIC_Send_NAck(void);
void Send_onebyte(u8 byte);
u8 Read_onebyte(u8 ack);

#endif
