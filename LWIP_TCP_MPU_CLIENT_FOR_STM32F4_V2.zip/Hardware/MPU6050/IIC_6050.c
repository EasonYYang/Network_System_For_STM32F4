/*
	IIC communication protocols and program.(Use GPIO to generate IIC sequence.)
	Use IIC to read/write a register, start waveform and stop waveform, also include wait-for-acknowledgement function.
	Author: 	Eason. Yang
	Contact:	yyichen@kth.se
	Date:		2019-07-29
*/

#include "IIC_6050.h"
#include "delay.h"
//#include "mpuiic.h"


#define DELAY_TIME_US 1

void IIC_6050_init(void)
{
	GPIO_InitTypeDef GPIIO_Init_Type;
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);//��ʹ������IO PORTBʱ�� 
	GPIIO_Init_Type.GPIO_Pin=GPIO_Pin_8|GPIO_Pin_9;            
    GPIIO_Init_Type.GPIO_Speed=GPIO_Speed_50MHz; 
	GPIIO_Init_Type.GPIO_Mode=GPIO_Mode_OUT;
	GPIIO_Init_Type.GPIO_OType=GPIO_OType_PP;
	GPIIO_Init_Type.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_Init(GPIOB,&GPIIO_Init_Type);//PB8 PB9
//	GPIO_SetBits(GPIOB,GPIO_Pin_10|GPIO_Pin_11);
}

void IIC_Start(void)
{
	MPU_SDA_OUT();
	
	MPU_IIC_SCL_OUT=1;//Sequence replacable..
	MPU_IIC_SDA_OUT=1;//Sequence replacable..
	delay_us(DELAY_TIME_US);
	MPU_IIC_SDA_OUT=0;
	delay_us(DELAY_TIME_US);
	MPU_IIC_SCL_OUT=0;	//ǯסI2C���ߣ�׼�����ͻ��������
}


void IIC_End(void)
{
	MPU_SDA_OUT();	
	MPU_IIC_SCL_OUT=0;//Sequence replacable. Why 00 --> 11???
	MPU_IIC_SDA_OUT=0;//Sequence replacable.
	delay_us(DELAY_TIME_US);
	MPU_IIC_SCL_OUT=1;
	delay_us(DELAY_TIME_US);// Ƶ�ʸߵ�ʱ��, ִ��
	MPU_IIC_SDA_OUT=1;//when SCL is set, SDA has a rising edge --> stop signal.
	delay_us(DELAY_TIME_US);
}


//return: 	0 succeed; 
//			1 failure;
u8 IIC_WaitACK(void)
{
	u8 Error_time=0;
	MPU_SDA_IN();
	MPU_IIC_SCL_OUT=1;
	delay_us(DELAY_TIME_US);
	while(MPU_IIC_SDA_IN)
	{
		Error_time++;
		if(Error_time>250) 
		{
			IIC_End();
			return 1;
		}
	}
	MPU_IIC_SCL_OUT=0;
	return 0;
}

void IIC_Send_Ack(void)
{
	MPU_IIC_SCL_OUT=0;	// sequence not replacable	ʱ�ӵ�ƽ����
	MPU_SDA_OUT();		// sequence not replacable	�ı� ֻ��/д�� ״̬
	//ʱ��ͼ�������clk��ƽ��ȷ�����յ����һλ���ݣ��ٸı��������״̬��
	MPU_IIC_SDA_OUT=0;
	delay_us(DELAY_TIME_US);
	MPU_IIC_SCL_OUT=1;
	delay_us(DELAY_TIME_US);
	MPU_IIC_SCL_OUT=0;
	delay_us(DELAY_TIME_US);
}

void IIC_Send_NAck(void)
{
	MPU_IIC_SCL_OUT=0;	// sequence not replacable
	MPU_SDA_OUT();		// sequence not replacable
	MPU_IIC_SDA_OUT=1;
	delay_us(DELAY_TIME_US);	
	MPU_IIC_SCL_OUT=1;
	delay_us(DELAY_TIME_US);
	MPU_IIC_SCL_OUT=0;
	delay_us(DELAY_TIME_US);
}


//return 	1: succeed;
//			0: ack not received;
void Send_onebyte(u8 byte)
{
	u8 t=8;
	MPU_SDA_OUT();
	MPU_IIC_SCL_OUT=0;
	
	for (;t>0;t--){
		MPU_IIC_SDA_OUT=0x01&(byte>>(t-1));
		delay_us(DELAY_TIME_US);
		MPU_IIC_SCL_OUT=1;
		delay_us(DELAY_TIME_US);
		MPU_IIC_SCL_OUT=0;
	}//��д���λ 
	delay_us(DELAY_TIME_US);
}

//ack=0 no ack; ack=1 ack sent
u8 Read_onebyte(u8 ack)
{
	unsigned char i,ret_val=0;
	MPU_SDA_IN();
	for(i=8;i>0;i--)
	{
		MPU_IIC_SCL_OUT=0;
		delay_us(DELAY_TIME_US);
		MPU_IIC_SCL_OUT=1;
		delay_us(DELAY_TIME_US);
		
		ret_val|=(MPU_IIC_SDA_IN<<(i-1));//�ȶ���λ
		delay_us(DELAY_TIME_US); 
	}
	if (!ack)	//MPU_IIC_Ack();	
		IIC_Send_NAck();//����nACK
    else	//MPU_IIC_NAck();
		IIC_Send_Ack(); //����ACK   
//	IIC_End();
	return ret_val;
}

