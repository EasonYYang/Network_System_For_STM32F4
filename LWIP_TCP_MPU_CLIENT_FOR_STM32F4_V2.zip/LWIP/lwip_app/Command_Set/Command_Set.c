/*
	TCP remote command identifying and processing program.
	Author: 	Eason. Yang
	Contact:	yyichen@kth.se
	Date:		2019-08-09
*/

#include "delay.h"
#include "led.h"
#include "malloc.h"
#include "stdio.h"
#include "string.h" 
//#include "Command_Set.h"
//#include "tcp_client_demo.h"
#include "BEEP.h"
#include "timer.h"
#include "lwip/pbuf.h"
#include "mpu6050.h"
#include "Command_all.h"

#include "inv_mpu.h"
#include "LCD.h"
#include "key.h"
#include "tcp_client_connection.h" 


extern struct tcp_pcb *tcppcb;
extern u8 tcp_client_flag;
extern u8 tcp_client_recvbuf[TCP_CLIENT_RX_BUFSIZE];

struct MPU_Raw *MPU_Package;

void Data_Process(struct MPU_Raw *Raw_data)
{
	u8 i;
	short scope=32768/2;
	for (i=0;i<3;i++)
	{
		Raw_data->gyro[i]=(int)(Raw_data->gyro[i])*100/scope;
		Raw_data->accel[i]=(int)(Raw_data->accel[i])*100/scope;
	} 
	Raw_data->pitch*=100;
	Raw_data->yaw*=100;
	Raw_data->roll*=100;
}


void send_info(struct tcp_pcb *tpcb,u8 data[])
{
//	struct tcp_client_struct *es; 
	struct pbuf *p;
	p=pbuf_alloc(PBUF_TRANSPORT, strlen((char*)data),PBUF_POOL);	//�����ڴ� 
	if(p!=NULL)
	{
		pbuf_take(p,(char*)data,strlen((char*)data));	//Copy 'tcp_client_sentbuf[]' to 'p_tx'
		if(tcp_write(tpcb,p->payload,p->len,TCP_WRITE_FLAG_COPY)== ERR_OK)
			tcp_output(tpcb);
		else pbuf_free(p);
		if(p!=NULL)	pbuf_free(p);//�ͷ��ڴ�	
	}
}

// Open the light bulb!
void func_com_1(void)
{
	//LED0=0;
	LED1=0;
	send_info(tcppcb,Comm_1_resp);
}
void func_com_2(void)
{
	//LED0=1;
	LED1=1;
	send_info(tcppcb,Comm_2_resp);
}
void func_com_3(void)
{	
	send_info(tcppcb,Comm_3_resp);
	TIM2_Int_Init(4999,7199);//��ʱ��2Ƶ��Ϊ2 hz
//	BEEP=1;
	delay_ms(10);
	PFout(8)=1;
	delay_ms(10);
//	delay_ms(400);
//	PBout(8)=0;
}

void func_com_4(void)
{
	u8 s=0,key;
	MPU_Package=mymalloc(SRAMIN,50);	//Ϊmemp_memory�����ڴ�
		
	if(MPU_Package==NULL)
			return;

	send_info(tcppcb,Comm_4_resp);

	TIM_Cmd(TIM5, ENABLE);  //����TIMx	
	TIM_ITConfig(TIM5,TIM_IT_Update,ENABLE ); //ʹ��ָ����TIM5�ж�,���������ж�
	
	while(mpu_dmp_init())
	{
		s++;		
		if(s>=10) 
		{
			printf("Time out! MPU6050 init failure!");
			send_info(tcppcb,Comm_6050_Init_Error);
			break;
		}
		printf("MPU6050 Error!\r\n");
		LCD_ShowString(30,130,200,16,16,"MPU6050 Error");
		delay_ms(200);
		LCD_Fill(30,130,239,130+16,WHITE);
 		delay_ms(200);
	}
	if(s>=20) 
	{
		return;
		
	}
	s=0;
	LCD_Clear(WHITE);
	LCD_Clear(WHITE);
	LCD_ShowString(30,30,200,16,16,"TCP Client Test for STM32F4");
	LCD_ShowString(30,50,200,16,16,"Eason. Yang");
	LCD_ShowString(30,70,200,16,16,"Contact: yyichen@kth.se"); 
	LCD_ShowString(30,110,200,16,16,"KEY_UP:Quit"); 
	LCD_ShowString(30,130,200,16,16,"MPU6050 OK");
	POINT_COLOR=BLUE;//	Colour: Blue 	 
 	LCD_ShowString(30,200,200,16,16," Temp:    . C");	
 	LCD_ShowString(30,220,200,16,16,"Pitch:    . C");	
 	LCD_ShowString(30,240,200,16,16," Roll:    . C");	 
 	LCD_ShowString(30,260,200,16,16," Yaw :    . C");
	POINT_COLOR=RED;//	Colour: Red 	 

	while(1)
	{
		lwip_periodic_handle();
		lwip_pkt_handle();
		s++;
		if(s%12==0)		{Show_RT_MPU(MPU_Package,1);s=0;}//t: refresh rate
		else	Show_RT_MPU(MPU_Package,0);
		key=KEY_Scan(0);
		if(key==WKUP_PRES)	
		{
			//tcp_client_flag&=~(1<<6);//Mark that the data was processed.
			send_info(tcppcb,Comm_Break_resp);
			LCD_Clear(WHITE);
			LCD_ShowString(30,30,200,16,16,"TCP Client Test for STM32F4");
			LCD_ShowString(30,50,200,16,16,"Eason. Yang");
			LCD_ShowString(30,70,200,16,16,"Contact: yyichen@kth.se"); 
			LCD_ShowString(30,110,200,16,16,"KEY_UP:Quit");  
			LCD_ShowString(30,130,200,16,16,"When break,please quit!");	
			LCD_ShowString(30,210,lcddev.width-30,lcddev.height-190,16,"STATUS:Connected   ");//��ʾ��Ϣ		
			POINT_COLOR=RED;
			LCD_ShowString(30,230,lcddev.width-30,lcddev.height-190,16,"Receive Data:");//��ʾ��Ϣ		
			POINT_COLOR=BLUE;//��ɫ����
			LCD_Fill(30,250,lcddev.width-1,lcddev.height-1,WHITE);//����һ������
			TIM_ITConfig(TIM5,TIM_IT_Update,DISABLE ); //ʹ��ָ����TIM5�ж�,���������ж�
			TIM_Cmd(TIM5, DISABLE);  //�ر�TIMx	
			MPU_Init();
			myfree(SRAMIN,MPU_Package);		
			return;
		}	
		
		if(tcp_client_flag&1<<6 && Is_equal(tcp_client_recvbuf,Comm_Set[COMMAND_NUM-1]))//Is the data received?
		{
			tcp_client_flag&=~(1<<6);//Mark that the data was processed.
			LCD_Clear(WHITE);			
			LCD_ShowString(30,30,200,16,16,"TCP Client Test for STM32F4");
			LCD_ShowString(30,50,200,16,16,"Eason. Yang");
			LCD_ShowString(30,70,200,16,16,"Contact: yyichen@kth.se");   
			LCD_ShowString(30,110,200,16,16,"KEY_UP:Quit");  
			LCD_ShowString(30,130,200,16,16,"When break,please quit!");	
			LCD_ShowString(30,210,lcddev.width-30,lcddev.height-190,16,"STATUS:Connected   ");//��ʾ��Ϣ		
			POINT_COLOR=RED;
			LCD_ShowString(30,230,lcddev.width-30,lcddev.height-190,16,"Receive Data:");//��ʾ��Ϣ		
			POINT_COLOR=BLUE;//��ɫ����
			LCD_Fill(30,250,lcddev.width-1,lcddev.height-1,WHITE);//����һ������

			func_com_6();
			MPU_Init();
			myfree(SRAMIN,MPU_Package);		
			return;
		}
		delay_ms(2);//can be modified.
	}
}

void func_com_5(void)
{
	func_com_4();
//	send_info(tcppcb,Comm_5_resp);	
//	TIM_ITConfig(TIM9,TIM_IT_Update,DISABLE ); //ʹ��ָ����TIM9�ж�,���������ж�
//	TIM_Cmd(TIM9, DISABLE);  //�ر�TIMx		
}

void func_com_6(void)
{
	send_info(tcppcb,Comm_6_resp);	
	TIM_ITConfig(TIM5,TIM_IT_Update,DISABLE ); //ʹ��ָ����TIM5�ж�,���������ж�
	TIM_Cmd(TIM5, DISABLE);  //�ر�TIMx	
//	TIM_ITConfig(TIM9,TIM_IT_Update,DISABLE ); //ʹ��ָ����TIM5�ж�,���������ж�
//	TIM_Cmd(TIM9, DISABLE);  //�ر�TIMx	
}


u8 Get_MPU_Data(struct MPU_Raw *MPU_Packet)
{
	/*
	if(MPU_Read_Len(MPU_ADDR,MPU_TEMP_OUTH_REG,2,MPU_Packet->raw_temperature))
		return 1;
	delay_us(1);
	if(MPU_Read_Len(MPU_ADDR,MPU_GYRO_XOUTH_REG,6,MPU_Packet->gyro))
		return 2;//gyro error
	delay_us(1);
	if(MPU_Read_Len(MPU_ADDR,MPU_ACCEL_XOUTH_REG,6,MPU_Packet->accel))
		return 3;//accel error
	delay_us(1);
	return 0;// OK
	*/
	MPU_Packet->raw_temperature=MPU_Get_Temperature();
	if(MPU_Get_Gyroscope(MPU_Packet->gyro,(MPU_Packet->gyro)+1,(MPU_Packet->gyro)+2))
		return 1;
	if(MPU_Get_Accelerometer(MPU_Packet->accel,(MPU_Packet->accel)+1,(MPU_Packet->accel)+2))
		return 2;
	
	return 0;
}

void convert(short x,u8 temp[8],u8 int_num) //prob (interpart bits) int_num=0 or 4
{
	u8 i;
	u16 base[4]={1000,100,10,1};
	if (int_num<=0 || int_num>4 ) return;
	if (x<0) {temp[0]='-';x=-x;}
	else temp[0]=' ';
	
	for(i=0;i<5;i++)
	{
		if (i<int_num)
		{
			temp[i+1]=x/base[i]+0x30;
			x%=base[i];
		}
		else if (i==int_num && int_num!=0 && int_num!=4)	temp[i+1]='.';
		
		else
		{
			temp[i+1]=x/base[i-1]+0x30;
			x%=base[i-1];
		}
	}
	temp[6]=',';
	temp[7]='\0';
//	printf((char*)temp);
}

void Send_MPU_Data(struct MPU_Raw *MPU_Packet)
{
	u8 tmp[8]={ ' ',0,0,'.',0,0,',',' '},i,nxt_line[2]="\r\n",nxt_line_2[3]=")\r\n";
	send_info(tcppcb,ASSERT_1);
	//delay_us(5);
	convert(MPU_Packet->raw_temperature,tmp,2);
	tmp[6]='\0';
	send_info(tcppcb,tmp);
	send_info(tcppcb,nxt_line);
		// Wait For ACK needed!
	
	
	send_info(tcppcb,ASSERT_2);
		// Wait For ACK needed!
	//delay_us(5);
	for (i=0;i<3;i++)
	{
		convert(MPU_Packet->gyro[i],tmp,2);
		if(i==2) tmp[6]='\0';
		send_info(tcppcb,tmp);
	}
	send_info(tcppcb,nxt_line_2);
		// Wait For ACK needed!
	
	send_info(tcppcb,ASSERT_3);
		// Wait For ACK needed!
	//delay_us(5);
	for (i=0;i<3;i++)
	{
		convert(MPU_Packet->accel[i],tmp,2);
		if(i==2) tmp[6]='\0';
		send_info(tcppcb,tmp);
	}
	send_info(tcppcb,nxt_line_2);

	convert((short)MPU_Packet->pitch/10,tmp,3);
	tmp[6]='\0';
	send_info(tcppcb,ASSERT_4);
	send_info(tcppcb,tmp);
	send_info(tcppcb,nxt_line);

	convert((short)MPU_Packet->roll/10,tmp,3);
	tmp[6]='\0';
	send_info(tcppcb,ASSERT_5);
	send_info(tcppcb,tmp);
	send_info(tcppcb,nxt_line);

	convert((short)MPU_Packet->yaw/10,tmp,3);
	tmp[6]='\0';
	send_info(tcppcb,ASSERT_6);
	send_info(tcppcb,tmp);	
	send_info(tcppcb,nxt_line);

	send_info(tcppcb,nxt_line);
	// Wait For ACK needed!
	
	
	
	//For TCP protocol, we need to receive ACK before sending new pkeacts!
}

void Construct_command_chain(struct comm_chain *Command)
{
	u8 i;
	comm_func p[]={func_com_1,func_com_2,func_com_3,func_com_4,func_com_5,func_com_6};
	for(i=0;i<COMMAND_NUM-1;i++)
	{
		Command->caption=Comm_Set[i];
		Command->comm_function=p[i];
		Command->next=Command+1;
		Command=Command->next;
	}
	// the last one
		Command->caption=Comm_Set[i];
		Command->next=NULL;
		Command->comm_function=p[i];
}	

void Show_RT_MPU(struct MPU_Raw *MPU_Packet,u8 t)//t: display
{
	/*
		float pitch,roll,yaw; 		//ŷ����
		short aacx,aacy,aacz;		//���ٶȴ�����ԭʼ����
		short gyrox,gyroy,gyroz;	//������ԭʼ����
		short temp;					//�¶�
	*/
		short temp;					//

		if(mpu_dmp_get_data(&(MPU_Packet->pitch),&(MPU_Packet->roll),&(MPU_Packet->yaw))==0)
		{ 
			temp=MPU_Packet->raw_temperature=MPU_Get_Temperature();	//�õ��¶�ֵ
			MPU_Get_Accelerometer(MPU_Packet->accel,MPU_Packet->accel+1,MPU_Packet->accel+2);	//�õ����ٶȴ���������
			MPU_Get_Gyroscope(MPU_Packet->gyro,MPU_Packet->gyro+1,MPU_Packet->gyro+2);	//�õ�����������
			//mpu6050_send_data(MPU_Packet->accel[0],MPU_Packet->accel[1],MPU_Packet->accel[2],MPU_Packet->gyro[0],MPU_Packet->gyro[1],MPU_Packet->gyro[2]);//���Զ���֡���ͼ��ٶȺ�������ԭʼ����
			//if(report)usart1_report_imu(aacx,aacy,aacz,gyrox,gyroy,gyroz,(int)(roll*100),(int)(pitch*100),(int)(yaw*10));
			if(t)
			{
				if(MPU_Packet->raw_temperature<0)
				{
					LCD_ShowChar(30+48,200,'-',16,0);		//��ʾ����
					MPU_Packet->raw_temperature=-MPU_Packet->raw_temperature;		//תΪ����
				}else LCD_ShowChar(30+48,200,' ',16,0);		//ȥ������ 
				LCD_ShowNum(30+48+8,200,temp/100,3,16);		//��ʾ��������	    
				LCD_ShowNum(30+48+40,200,temp%10,1,16);		//��ʾС������
				
				temp=(short)MPU_Packet->pitch*10;
				if(temp<0)
				{
					LCD_ShowChar(30+48,220,'-',16,0);		//��ʾ����
					temp=-temp;		//תΪ����
				}else LCD_ShowChar(30+48,220,' ',16,0);		//ȥ������ 
				LCD_ShowNum(30+48+8,220,temp/10,3,16);		//��ʾ��������	    
				LCD_ShowNum(30+48+40,220,temp%10,1,16);		//��ʾС������ 

				temp=(short)MPU_Packet->roll*10;
				if(temp<0)
				{
					LCD_ShowChar(30+48,240,'-',16,0);		//��ʾ����
					temp=-temp;		//תΪ����
				}else LCD_ShowChar(30+48,240,' ',16,0);		//ȥ������ 
				LCD_ShowNum(30+48+8,240,temp/10,3,16);		//��ʾ��������	    
				LCD_ShowNum(30+48+40,240,temp%10,1,16);		//��ʾС������ 

				temp=(short)MPU_Packet->yaw*10;
				if(temp<0)
				{
					LCD_ShowChar(30+48,260,'-',16,0);		//��ʾ����
					temp=-temp;		//תΪ����
				}else LCD_ShowChar(30+48,260,' ',16,0);		//ȥ������ 
				LCD_ShowNum(30+48+8,260,temp/10,3,16);		//��ʾ��������	    
				LCD_ShowNum(30+48+40,260,temp%10,1,16);		//��ʾС������  

				LED0=!LED0;//LED��˸
			}
		}
}


